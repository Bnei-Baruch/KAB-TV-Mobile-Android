//
//  MainViewController.m
//  kxmovie
//
//  Created by Kolyvan on 18.10.12.
//  Copyright (c) 2012 Konstantin Boukreev . All rights reserved.
//
//  https://github.com/kolyvan/kxmovie
//  this file is part of KxMovie
//  KxMovie is licenced under the LGPL v3, see lgpl-3.0.txt

#import "MainViewController.h"
#import "KxMovieViewController.h"
#import "LoginControllerViewController.h"
@interface MainViewController () {
    NSArray *_localMovies;
    NSArray *_remoteMovies;
}
@property (strong, nonatomic) UITableView *tableView;
@end

@implementation MainViewController

- (id)init
{
    self = [super init];
    if (self) {
        self.title = @"Streams";
//        self.tabBarItem = [[UITabBarItem alloc] initWithTabBarSystemItem:UITabBarSystemItemMore tag: 0];
//        self.tabBarController = [[UITabBarController alloc]init];
//        self.tabBarController.viewControllers = [[NSArray alloc] initWithObjects:self, nil];
//        self.tabBarController.delegate = self;
        
        _remoteMovies = @[
//            @"http://www.wowza.com/_h264/BigBuckBunny_175k.mov",
//            // @"http://www.wowza.com/_h264/BigBuckBunny_115k.mov",
//            @"rtsp://184.72.239.149/vod/mp4:BigBuckBunny_115k.mov",
//            @"http://santai.tv/vod/test/test_format_1.3gp",
//            @"http://santai.tv/vod/test/test_format_1.mp4",
        @"http://icecast.kab.tv/heb.mp3",
        @"mmst://wms1.il.kab.tv/heb",
        @"http://icecast.kab.tv/live1-heb-574bcfd5.mp3"
        
            //@"rtsp://184.72.239.149/vod/mp4://BigBuckBunny_175k.mov",
            //@"http://santai.tv/vod/test/BigBuckBunny_175k.mov",
        ];
        
    }
    return self;
}

//- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController
//{
//    
//    NSLog(@"Tab bar selected");
//}

- (void)loadView
{
    self.view = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
    self.tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStyleGrouped];
    self.tableView.backgroundColor = [UIColor whiteColor];
    //self.tableView.backgroundView = [[UIImageView alloc] initWithImage:image];
    self.tableView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleBottomMargin;
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    
    [self.view addSubview:self.tableView];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];    
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [self reloadMovies];
    [self.tableView reloadData];
}

- (void) reloadMovies
{
    NSMutableArray *ma = [NSMutableArray array];
    NSFileManager *fm = [[NSFileManager alloc] init];
    NSString *folder = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,
                                                            NSUserDomainMask,
                                                            YES) lastObject];
    NSArray *contents = [fm contentsOfDirectoryAtPath:folder error:nil];
    
    for (NSString *filename in contents) {
        
        if (filename.length > 0 &&
            [filename characterAtIndex:0] != '.') {
            
            NSString *path = [folder stringByAppendingPathComponent:filename];
            NSDictionary *attr = [fm attributesOfItemAtPath:path error:nil];
            if (attr) {
                id fileType = [attr valueForKey:NSFileType];
                if ([fileType isEqual: NSFileTypeRegular]) {
                    
                    NSString *ext = path.pathExtension.lowercaseString;
                    
                    if ([ext isEqualToString:@"mp3"] ||
                        [ext isEqualToString:@"caff"]||
                        [ext isEqualToString:@"aiff"]||
                        [ext isEqualToString:@"ogg"] ||
                        [ext isEqualToString:@"wma"] ||
                        [ext isEqualToString:@"m4a"] ||
                        [ext isEqualToString:@"m4v"] ||
                        [ext isEqualToString:@"3gp"] ||
                        [ext isEqualToString:@"mp4"] ||
                        [ext isEqualToString:@"mov"] ||
                        [ext isEqualToString:@"avi"] ||
                        [ext isEqualToString:@"mkv"] ||
                        [ext isEqualToString:@"mpeg"]||
                        [ext isEqualToString:@"mpg"] ||
                        [ext isEqualToString:@"flv"] ||
                        [ext isEqualToString:@"vob"]) {
                        
                        [ma addObject:path];
                    }
                }
            }
        }
    }
    
    //_localMovies = [ma copy];
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if([[defaults objectForKey:@"activated"] isEqualToString:@"yes"])
    {
        //yuval - the user is loged in
        
    }
    else
    {
        _localMovies = [[NSArray alloc] initWithObjects:@"Login", nil];
    }
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    switch (section) {
        case 0:     return @"Channel 66";
        case 1:     return @"Extra";
    }
    return @"";
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    switch (section) {
        case 0:     return _remoteMovies.count;
        case 1:     return _localMovies.count;
    }
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"Cell";
    UITableViewCell *cell = [self.tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                      reuseIdentifier:cellIdentifier];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    
    NSString *path;
    
    if (indexPath.section == 0) {
        
        path = _remoteMovies[indexPath.row];
        
    } else {
        
        path = _localMovies[indexPath.row];
    }

    cell.textLabel.text = path.lastPathComponent;
    return cell;
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *path;
    
    if (indexPath.section == 0) {
        
        path = _remoteMovies[indexPath.row];
        
    } else {
        
        path = _localMovies[indexPath.row];
        if([path isEqualToString:@"Login"])
        {
            /*
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"PASS", nil)
                                                                message:@"ENTER PASSWORD"
                                                               delegate:nil
                                                      cancelButtonTitle:NSLocalizedString(@"Ok", @"Cancel")
                                                      otherButtonTitles:nil];
           
            alertView.alertViewStyle = UIAlertViewStyleSecureTextInput;
            
            UITextField * alertTextField = [alertView textFieldAtIndex:0];
            
            alertTextField.keyboardType = UIKeyboardTypeAlphabet;
            alertTextField.placeholder = @"Enter password";
            */
            
            NSUserDefaults *userD = [[NSUserDefaults alloc] init];
            if ([@"1" isEqualToString:[userD objectForKey:@"isLogin"]]) {
                [self openSvivaTova];
            } else {
                [self showAlertWithText];
            }
            
            
            
            
            
            
            //[alertView show];
            /*
                LoginControllerViewController *web = [[LoginControllerViewController alloc]init];
                
                
                [self.navigationController pushViewController:web animated:YES];
            */
            return;
        }
    }

    KxMovieViewController *vc = [KxMovieViewController movieViewControllerWithContentPath:path];
    [self presentViewController:vc animated:YES completion:nil];
    //[self.navigationController pushViewController:vc animated:YES];    
}

-(void)showAlertWithText {

    UIAlertView *passwordAlert = [[UIAlertView alloc] initWithTitle:@"Enter Password" message:@"\n\n\n"
                                                           delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel",nil) otherButtonTitles:NSLocalizedString(@"OK",nil), nil];
    passwordAlert.tag = 1;
    
    UILabel *passwordLabel = [[UILabel alloc] initWithFrame:CGRectMake(12,40,260,25)];
    passwordLabel.font = [UIFont systemFontOfSize:16];
    passwordLabel.textColor = [UIColor whiteColor];
    passwordLabel.backgroundColor = [UIColor clearColor];
    passwordLabel.shadowColor = [UIColor blackColor];
    passwordLabel.shadowOffset = CGSizeMake(0,-1);
    passwordLabel.textAlignment = UITextAlignmentCenter;
    passwordLabel.text = @"Account Name";
    [passwordAlert addSubview:passwordLabel];
    
    UIImageView *passwordImage = [[UIImageView alloc] initWithImage:[UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"passwordfield" ofType:@"png"]]];
    passwordImage.frame = CGRectMake(11,79,262,31);
    [passwordAlert addSubview:passwordImage];
    
    UITextField *passwordField = [[UITextField alloc] initWithFrame:CGRectMake(16,83,252,25)];
    passwordField.font = [UIFont systemFontOfSize:18];
    passwordField.backgroundColor = [UIColor whiteColor];
    passwordField.secureTextEntry = YES;
    passwordField.keyboardAppearance = UIKeyboardAppearanceAlert;
    //passwordField.delegate = self;
    [passwordField becomeFirstResponder];
    passwordField.borderStyle = UITextBorderStyleRoundedRect;
    passwordField.tag = 100;
    [passwordAlert addSubview:passwordField];
    
    
    
    //[passwordAlert setTransform:CGAffineTransformMakeTranslation(0,109)];
    [passwordAlert show];

}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    NSLog(@"textFieldDidEndEditing");
    
    
    
    
}

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex {
    NSLog(@"didDismissWithButtonIndex");
    
    //get the textField from the UIalertView
    UITextField *getTextView = (UITextField*)[alertView viewWithTag:100];
    NSLog(@"key pressed = %d, getTextView = %@", buttonIndex, getTextView.text);
    
    if (buttonIndex == 1 && ([@"arvut" caseInsensitiveCompare:getTextView.text] == NSOrderedSame ) ) {
            [self openSvivaTova];
        
        NSUserDefaults *userD = [[NSUserDefaults alloc] init];
        [userD setObject:@"1" forKey:@"isLogin"];
        [userD synchronize];
    }

    
    
}
-(void)openSvivaTova{
    
    LoginControllerViewController *web = [[LoginControllerViewController alloc]init];
    
    
    [self.navigationController pushViewController:web animated:YES];
}
@end
