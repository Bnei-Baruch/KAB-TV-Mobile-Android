//
//  LoginController.m
//  kxmovie
//
//  Created by Igal Avraham on 12/14/12.
//
//

#import "LoginController.h"

@implementation LoginController

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
