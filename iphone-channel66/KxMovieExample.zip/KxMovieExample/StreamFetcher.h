//
//  StreamFetcher.h
//  kxmovie
//
//  Created by Igal Avraham on 12/14/12.
//
//

#import <Foundation/Foundation.h>

@interface StreamFetcher : NSObject
{
    NSDictionary *jsonData;
    
}
@end
