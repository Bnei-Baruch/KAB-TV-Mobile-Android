//
//  ChooseQualityViewController.h
//  kxmovie
//
//  Created by Yuval Ovadia on 3/8/13.
//
//

#import <UIKit/UIKit.h>

@interface ChooseQualityViewController : UIViewController<UITableViewDataSource, UITableViewDelegate>

@end
