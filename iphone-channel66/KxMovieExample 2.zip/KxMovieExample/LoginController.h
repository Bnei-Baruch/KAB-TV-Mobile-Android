//
//  LoginController.h
//  kxmovie
//
//  Created by Igal Avraham on 12/14/12.
//
//

#import <UIKit/UIKit.h>

@interface LoginController : UIWebView

@end
